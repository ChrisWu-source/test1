﻿namespace Futures.Models
{
    public class RolesPageModel
    {
        public int? Pagesld { get; set; }
        public string? Role { get; set; }
        public string? ParentPage { get; set; }
        public string? ChildPage { get; set; }
        public DateTime? Createdate { get; set; }
        public string? Creator { get; set; }
        public DateTime? Maintenancedate { get; set; }
        public string? Maintainer { get; set; }
    }
}
