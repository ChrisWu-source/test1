﻿namespace Futures.Service.Interface
{
    public interface IRoles
    {
        /// <summary>
        /// 新增Role
        /// </summary>
        void Create();
        /// <summary>
        /// 刪除Role
        /// </summary>
        void Delete();
        /// <summary>
        /// 查詢ByID
        /// </summary>
        /// <param name="id"></param>
        void GetById(string id);
        /// <summary>
        /// 更新Role
        /// </summary>
        void Update();
        
    }
}
