﻿namespace Futures.Service.Interface
{
    public class IRoleIRoleService : IRoles
    {
        /// <summary>
        /// 新增Role
        /// </summary>
        public void Create()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 刪除Role
        /// </summary>
        public void Delete()
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 查詢ByID
        /// </summary>
        /// <param name="id"></param>
        public void GetById(string id)
        {
            throw new NotImplementedException();
        }
        /// <summary>
        /// 更新Role
        /// </summary>
        public void Update()
        {
            throw new NotImplementedException();
        }
    }
}
